#ifndef ICNSPRC_H
#define ICNSPRC_H
extern void icnsprc(void);
#endif /* ICNSPRC_H */
