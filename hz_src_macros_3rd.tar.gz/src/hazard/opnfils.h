#ifndef OPNFILS_H
#define OPNFILS_H

extern void opnfils(char *);

#endif /* OPNFILS_H */
