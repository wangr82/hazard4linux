#ifndef OBSSTAT_H
#define OBSSTAT_H

void obsstat(void);
#endif /* OBSSTAT_H */

