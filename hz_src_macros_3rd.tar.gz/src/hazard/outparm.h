#ifndef OUTPARM_H
#define OUTPARM_H

void outparm(char *phase,int chgno,int parmno,double spcval,
	     double useval,char *estnam);
#endif /* OUTPARM_H */
