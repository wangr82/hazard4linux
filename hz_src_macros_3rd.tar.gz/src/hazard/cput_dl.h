#ifndef CPUT_DL_H
#define CPUT_DL_H
void cput_dl(char *phasnm,int j);
#endif /* CPUT_DL_H */
