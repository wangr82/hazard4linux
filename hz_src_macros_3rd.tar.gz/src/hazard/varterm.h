#ifndef VARTERM_H
#define VARTERM_H

void varterm(void);
#endif /* VARTERM_H */
