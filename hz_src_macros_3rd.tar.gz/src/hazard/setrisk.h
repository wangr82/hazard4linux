#ifndef SETRISK_H
#define SETRISK_H
void setrisk(void);

#endif /* SETRISK_H */
