#include <string.h>
#include "shape.h"

void hzrg(void){
  shape();
}
