#ifndef OUTCMOD_H
#define OUTCMOD_H

void outcmod(void);
#endif /* OUTCMOD_H */
