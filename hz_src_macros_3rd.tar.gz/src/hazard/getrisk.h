#ifndef GETRISK_H
#define GETRISK_H

void getrisk(void);

#endif /* GETRISK_H */
