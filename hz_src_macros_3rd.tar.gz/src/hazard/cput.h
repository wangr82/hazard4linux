#ifndef CPUT_H
#define CPUT_H

void cput(char *phasnm,int j);
#endif /* CPUT_H */
