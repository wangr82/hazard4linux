#ifndef SETPARM_H
#define SETPARM_H

void setparmno(int parmno,int ispecno,int phaseno,double *fixpvar);

#endif /* SETPARM_H */
