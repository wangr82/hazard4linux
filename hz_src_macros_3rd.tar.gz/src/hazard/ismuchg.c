#include <string.h>
void ismuchg(float spec,float used,char *flag){
  if(spec!=used)
    *flag = '*';
}
