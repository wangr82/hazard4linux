#ifndef OUTEQUN_H
#define OUTEQUN_H

void outequn(char *equnam);
#endif /* OUTEQUN_H */
