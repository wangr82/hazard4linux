#ifndef OUTEMOD_H
#define OUTEMOD_H
void outemod(void);
#endif /* OUTEMOD_H */
