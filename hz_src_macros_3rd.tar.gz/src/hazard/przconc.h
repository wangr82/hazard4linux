#ifndef PRZCONC_H
#define PRZCONC_H

void przconc(void);
#endif /* PRZCONC_H */
