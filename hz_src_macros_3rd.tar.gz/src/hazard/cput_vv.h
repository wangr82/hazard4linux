#ifndef CPUT_VV_H
#define CPUT_VV_H

void cput_vv(char *phasnm,int *iary,void (*cputfn)(char *,int));
#endif /* CPUT_VV_H */
