#ifndef READCt_H
#define READCt_H

void readct(void);
#endif /* READCt */

