#ifndef PARMPRC_H
#define PARMPRC_H

extern void parmprc(void);

#endif /* PARMPRC_H */
