#ifndef EVNTPRC_H
#define EVNTPRC_H

extern void evntprc(void);

#endif /* EVNTPRC_H */
