#ifndef HZRG_H
#define HZRG_H
void hzrg(void);

#endif /* HZRG_H */
