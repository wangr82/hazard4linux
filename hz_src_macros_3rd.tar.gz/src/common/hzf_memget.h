#ifndef HZF_MEMGET_H
#define HZF_MEMGET_H

void *hzf_memget(int leng);

#endif /* HZF_MEMGET_H */

