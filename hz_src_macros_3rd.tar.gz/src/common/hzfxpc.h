#ifndef HZFXPC_H
#define HZFXPC_H

void hzfxpc(char *strg,int leng,int column);

#endif /* HZFXPC_H */
