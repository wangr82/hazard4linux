#ifndef HZFXPI_H
#define HZFXPI_H

void hzfxpi(int value,int places,int column);

#endif /* HZFXPI_H */
