#ifndef  HZD_LN_A_DIV_B_H
#define  HZD_LN_A_DIV_B_H

double hzd_ln_A_div_B(double A,double B);
#endif  /* HZD_LN_A_DIV_B_H */
