#ifndef STMTFLD_H
#define STMTFLD_H

double stmtfld(int fldno);

#endif /* STMTFLD_H */
