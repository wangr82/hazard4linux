#ifndef XVPUTI_H
#define  XVPUTI_H

void xvputi(int nvar);

#endif /* XVPUTI_H */



