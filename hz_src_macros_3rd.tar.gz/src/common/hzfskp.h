#ifndef HZFSKP_H
#define HZFSKP_H

void hzfskp(int count);

#endif /* HZFSKP_H */
