#ifndef HZFLG2_H
#define HZFLG2_H

void hzflg2(char *strg1,int leng1,char *strg2,int leng2);

#endif /* HZFLG2_H */
