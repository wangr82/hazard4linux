#ifndef HZD_LN_G1_AND_SG1_H
#define HZD_LN_G1_AND_SG1_H

void hzd_ln_G1_and_SG1(void);
#endif /* HZD_LN_G1_AND_SG1_H */
