#ifndef SETVAR_H
#define SETVAR_H

void setvar(int which,char *name);
#endif /* SETVAR_H */
