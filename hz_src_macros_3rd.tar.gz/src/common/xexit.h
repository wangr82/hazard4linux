#ifndef XEXIT_H
#define XEXIT_H

void xexit(int rc);

#endif /* XEXIT_H */
