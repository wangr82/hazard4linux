#ifndef HZD_LN_1MIN_E_NEGEX_H
#define HZD_LN_1MIN_E_NEGEX_H

double hzd_ln_1min_e_negeX(double lnX);
#endif /* HZD_LN_1MIN_E_NEGEX_H */
