#ifndef CHLSKM_H
#define CHLSKM_H

void CHLSKM(double *a,double *wk1,double *wk2,double *sx,int n, int iop);
#endif /* CHLSKM_H */
