#ifndef RESTOR_H
#define RESTOR_H

void RESTOR(double *beta,int nvar,int *index,double *theta);
#endif /* RESTOR_H */
