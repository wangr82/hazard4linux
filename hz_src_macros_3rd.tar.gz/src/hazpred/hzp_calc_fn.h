#ifndef HZP_CALC_FN_H
#define HZP_CALC_FN_H

void hzp_calc_fn(void);
#endif /* HZP_CALC_FN_H */
