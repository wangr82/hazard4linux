#ifndef CNTOBSH_H
#define CNTOBSH_H
void cntobsh(void);

#endif /* CNTOBSH_H */
