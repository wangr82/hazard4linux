#ifndef HZP_CALC_HAZARD_H
#define HZP_CALC_HAZARD_H

void hzp_calc_hazard(void);
#endif /* HZP_CALC_HAZARD_H */
