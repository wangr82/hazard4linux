#ifndef ADDVARS_H
#define ADDVARS_H

void addvars(void);
#endif /* ADDVARS_H */

