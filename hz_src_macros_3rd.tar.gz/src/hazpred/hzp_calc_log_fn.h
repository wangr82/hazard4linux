#ifndef HZP_CALC_LOG_FN_H
#define HZP_CALC_LOG_FN_H
void hzp_calc_log_fn(void);
#endif /* HZP_CALC_LOG_FN_H */
