#ifndef OBSVERR_H
#define OBSVERR_H

void obsverr(int obsnum);
#endif /* OBSVERR_H */
