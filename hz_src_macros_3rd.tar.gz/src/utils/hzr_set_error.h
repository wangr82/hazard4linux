#ifndef  HZR_SET_ERROR_H
#define  HZR_SET_ERROR_H

void hzr_set_error(char *location,int errorset);
#endif /* HZR_SET_ERROR_H */
