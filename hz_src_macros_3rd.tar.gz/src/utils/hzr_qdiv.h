#ifndef HZR_QDIV_H
#define HZR_QDIV_H

#include "common.h"
xtended hzr_qdiv(xtended a,xtended c);
#endif /* HZR_QDIV_H */
