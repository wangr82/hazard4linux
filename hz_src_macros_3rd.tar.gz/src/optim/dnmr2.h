#ifndef DNMR2_H
#define DNMR2_H

double DNMR2(double *sx,int n,int incx);

#endif /* DNMR2_H */
