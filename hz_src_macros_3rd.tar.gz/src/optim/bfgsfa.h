#ifndef BFGSFA_H
#define BFGSFA_H
void BFGSFA(double *m,double *gc,double *gplus, double *s,
	    double *y, double eta,logical angrad,int n);
#endif /* BFGSFA_H */
