#ifndef SETOPT_H
#define SETOPT_H

void setoptim(void);
void optim(void);

#endif /* SETOPT_H */
