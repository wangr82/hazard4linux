#ifndef NORMAL_H
#define NORMAL_H

double NORMAL(double z);

#endif /* NORMAL_H */
