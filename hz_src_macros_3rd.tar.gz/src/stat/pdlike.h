#ifndef PDLIKE_H
#define PDLIKE_H

double PDLIKE(double llike1,double llike2,int df);

#endif /* PDLIKE_H */
