#ifndef STEPW_H
#define STEPW_H

void STEPW(short int *status,double *pvalue,int *moves,int *mxmove,
	   double *zvalue,double *stdErr,int *flags,double *qx,
	   double *qtols,double *d2ll,int nvar,double *wk,double *d2llad,
	   int *rstvec);

 
#endif /* STEPW_H */
