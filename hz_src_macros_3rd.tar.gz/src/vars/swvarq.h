#ifndef SWVARQ_H
#define SWVARQ_H
void SWVARQ(short int *status,double *pvalue,double *zvalue,
	    double *stdErr,int *flags,double *qx, double *qtols,
	    double *d2ll,int nvar,double *wk, double *d2llad);
#endif /* SWVARQ_H */
