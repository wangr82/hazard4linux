#ifndef HZR_QINIT_H
#define HZR_QINIT_H
void hzr_qinit(void);

#endif /* HZR_QINIT_H */
