#ifndef HZR_CALC_LOGE_MU_H
#define HZR_CALC_LOGE_MU_H

void hzr_calc_loge_mu(void);

#endif /* HZR_CALC_LOGE_MU_H */
