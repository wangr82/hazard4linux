#ifndef HZR_QSUM_H
#define HZR_QSUM_H
#include "common.h"
xtended hzr_qsum(xtended a,xtended c);
#endif /* HZR_QSUM_H */
