#ifndef SETLIK_H
#define SETLIK_H

#include "structures.h" /* Defines logical data type */

void dllike(double *llike);
logical SETLIK_obs_loop(void);
 
#endif /* SETLIK_H */

