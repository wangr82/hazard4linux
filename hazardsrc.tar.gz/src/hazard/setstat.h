#ifndef SETSTAT_H
#define SETSTAT_H
void setstat(int i,int idx,int *phasevar,int *itabl,long *ipxc);
#endif /* SETSTAT_H */
