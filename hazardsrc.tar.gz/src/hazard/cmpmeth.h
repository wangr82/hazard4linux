#ifndef CMPMETH_H
#define CMPMETH_H

void cmpmeth(void);
#endif /* CMPMETH_H */
