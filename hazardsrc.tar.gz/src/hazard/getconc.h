#ifndef GETCONC_H
#define GETCONC_H
void getconc(void);
#endif /* GETCONC_H */
