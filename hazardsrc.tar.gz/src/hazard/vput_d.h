#ifndef VPUT_D_H
#define VPUT_D_H
void vput_d(char *spcnam,char *varnam,int misval,int delval,
	    double minval, double maxval,size_t spclen);
#endif /* VPUT_D_H */
