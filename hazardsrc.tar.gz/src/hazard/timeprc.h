#ifndef TIMEPRC_H
#define TIMEPRC_H

extern void timeprc(void);

#endif /* TIMEPRC_H */
