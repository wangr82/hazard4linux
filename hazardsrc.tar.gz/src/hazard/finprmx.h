#ifndef FINPRMX_H
#define FINPRMX_H

void finprmx(int *i,int phasno,int spt,int ept);
#endif /* FINPRMX_H */
