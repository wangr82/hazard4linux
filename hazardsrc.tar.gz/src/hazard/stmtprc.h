#ifndef STMTPRC_H
#define STMTPRC_H

extern void stmtprc(void);

#endif /* STMTPRC_H */
