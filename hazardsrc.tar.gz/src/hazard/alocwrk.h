#ifndef ALOCWRK_H
#define ALOCWRK_H

void alocwrk(void);
#endif /* ALOCWRK */

