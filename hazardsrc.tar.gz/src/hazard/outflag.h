#ifndef OUTFLAG_H
#define OUTFLAG_H
void outflag(char *flgnam,logical value);
#endif /* OUTFLAG_H */
