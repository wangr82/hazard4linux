#ifndef MEMCLC2_H
#define MEMCLC2_H
void memclc2(int phasno,int xt1st,int *xt2nd);
#endif /* MEMCLC2_H */
