#ifndef WGHTPRC_H
#define WGHTPRC_H

extern void wghtprc(void);

#endif /* WGHTPRC_H */
