#ifndef SETPRMF_H
#define SETPRMF_H

void setprmf(int,int,int,int,double *);

#endif /* SETPRMF_H */
