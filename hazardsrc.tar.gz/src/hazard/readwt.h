#ifndef READWT_H
#define READWT_H

void readwt(void);
#endif /* READWT */

