#ifndef SETIDXS_H
#define SETIDXS_H
void setidxs(int i,int j);
#endif /* SETIDXS_H */

