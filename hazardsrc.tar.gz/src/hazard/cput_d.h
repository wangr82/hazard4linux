#ifndef CPUT_D_H
#define CPUT_D_H

void cput_d(char *phasnm,int j);
#endif /* CPUT_D_H */

