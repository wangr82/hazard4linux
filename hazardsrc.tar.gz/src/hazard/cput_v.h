#ifndef CPUT_V_H
#define CPUT_V_H

void cput_v(int dashct,int dashat,void (*cputfn)(char *,int));
#endif /* CPUT_V_H */

