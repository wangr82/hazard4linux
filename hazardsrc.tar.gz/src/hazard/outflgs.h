#ifndef OUTFLGS_H
#define OUTFLGS_H

void outflgs(void);
#endif /* OUTFLGS_H */

