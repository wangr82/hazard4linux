#ifndef VFYNVAR_H
#define VFYNVAR_H

extern int vfynvar(struct namestr *,char *);

#endif /* VFYNVAR_H */
