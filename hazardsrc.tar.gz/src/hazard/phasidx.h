#ifndef PHASIDX_H
#define PHASIDX_H
void phasidx(int *i,int phasno,int spt,int ept);
#endif /* PHASIDX_H */
