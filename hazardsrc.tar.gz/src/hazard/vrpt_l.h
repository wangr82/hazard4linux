#ifndef VRPT_L_H
#define VRPT_L_H

void vrpt_l(void);
#endif/* VRPT_L_H */
