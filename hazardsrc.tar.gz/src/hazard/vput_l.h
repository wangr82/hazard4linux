#ifndef VPUT_L_H
#define VPUT_L_H

void vput_l(char *spcnam,char *varnam,char *label,double minval,
	    double maxval, size_t spclen);
#endif /* VPUT_L_H */
