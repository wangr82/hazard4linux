#ifndef VPUT_H
#define VPUT_H
void vput(char *spcnam,char *varnam,double minval,double maxval,
	  size_t spclen);

#endif /* VPUT_H */
