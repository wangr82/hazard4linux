#ifndef OUTMODS_H
#define OUTMODS_H


void outmods(void);
#endif /* OUTMODS_H */
