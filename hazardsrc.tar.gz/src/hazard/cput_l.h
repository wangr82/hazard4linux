#ifndef CPUT_L_H
#define CPUT_L_H

void cput_l(char *phasnm,int j);
#endif /* CPUT_L_H */
