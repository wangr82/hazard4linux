#ifndef CNTOBS_H
#define CNTOBS_H
void cntobs(void);
#endif /* CNTOBS_H */
