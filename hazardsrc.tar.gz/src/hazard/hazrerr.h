#ifndef HAZRERR_H
#define HAZRERR_H
void hazrerr(void);
#endif /* HAZRERR_H */

