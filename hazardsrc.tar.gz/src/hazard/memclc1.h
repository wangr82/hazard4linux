#ifndef MEMCLC1_H
#define MEMCLC1_H
void memclc1(int phasno,int xt1st,int *xt2nd,int *xt3rd,
	     int *xt4th,int *xt5th);
#endif /* MEMCLC1_H */
