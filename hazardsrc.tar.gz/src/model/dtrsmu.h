#ifndef DTRSMU_H
#define DTRSMU_H

void DTRSMU(short int iop);
#endif /* DTRSMU_H */
