#ifndef CHOSLV_H
#define CHOSLV_H
void CHOSLV(double *l,double *g,double *s,int n);

#endif /* CHOSLV_H */
