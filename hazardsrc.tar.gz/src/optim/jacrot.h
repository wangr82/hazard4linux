#ifndef JACROT_H
#define JACROT_H

void JACROT(double *m,double a,double b,int i,int n);

#endif /* JACROT_H */
