#ifndef QRUPDT_H
#define QRUPDT_H

void QRUPDT(double *m,double *u,double *v,int n);

#endif /* QRUPDT_H */
