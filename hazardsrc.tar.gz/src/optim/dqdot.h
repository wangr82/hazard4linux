#ifndef DQDOT_H
#define DQDOT_H

double DQDOT(double *x,double *y,int n);

#endif /* DQDOT_H */
