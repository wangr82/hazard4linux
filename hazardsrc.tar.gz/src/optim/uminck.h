#ifndef UMINCK_H
#define UMINCK_H
void UMINCK(void);
void RECHK(double *x0,double *typx,double *sx,double *typf,double *maxstp,
	   int n);

#endif /* UMINCK_H */
