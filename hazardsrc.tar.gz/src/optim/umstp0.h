#ifndef UMSTP0_H
#define UMSTP0_H

void UMSTP0(double *x0,double f0,double *g0,double *sx,double typf,
	    double gradtl,int *trmcod,int *consec,int n);
#endif /* UMSTP0_H */

