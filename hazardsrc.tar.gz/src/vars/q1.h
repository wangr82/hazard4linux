#ifndef Q1_H
#define Q1_H

double Q1(double *a,double grad,double *b1,double *qtol,int *err,
	  double *wk,int n);

#endif /* Q1_H */
