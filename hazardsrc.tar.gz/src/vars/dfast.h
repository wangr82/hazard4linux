#ifndef DFAST_H
#define DFAST_H

void DFAST(double *beta,int nvar,double *cov,int ivar,double *sd,
	   double *znorm,double *pnorm);

#endif /* DFAST_H */
