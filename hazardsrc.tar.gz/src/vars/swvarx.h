#ifndef SWVARX_H
#define SWVARX_H
void SWVARX(short int *status,double *pvalue,int *moves,int *mxmove);
#endif /* SWVARX_H */

