#ifndef SWVARI_H
#define SWVARI_H
void SWVARI(short int *status,double *pvalue,int *moves,int *mxmove,
	    double *zvalue,int *flags,int *rstvec);

#endif /* SWVARI_H */
