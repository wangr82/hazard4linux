#ifndef HZPP_H
#define HZPP_H

void hzpp(void);
#endif /* HZPP_H */
