#ifndef HZP_REFMT_COV_H
#define HZP_REFMT_COV_H

void hzp_refmt_cov(void);
#endif /* HZP_REFMT_COV_H */
