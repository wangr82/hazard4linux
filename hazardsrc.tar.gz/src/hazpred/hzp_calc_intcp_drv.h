#ifndef HZP_CALC_INTCP_DRV_H
#define HZP_CALC_INTCP_DRV_H
void hzp_calc_intcp_drv(void);
#endif /* HZP_CALC_INTCP_DRV_H */
