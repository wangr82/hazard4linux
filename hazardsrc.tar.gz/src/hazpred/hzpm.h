#ifndef HZPM_H
#define HZPM_H
void hzpm(int obsCnt);
#endif /* HZPM_H */
