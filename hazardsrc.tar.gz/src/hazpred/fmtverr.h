#ifndef FMTVERR_H
#define FMTVERR_H

void fmtverr(int varnum,char *name,char *namv);
#endif /* FMTVERR_H */
