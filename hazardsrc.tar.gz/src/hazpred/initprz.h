#ifndef INITPRZ_H
#define INITPRZ_H

void initprz(void);
#endif /* INITPRZ_H */
