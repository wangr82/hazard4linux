#ifndef GETHAZR_H
#define GETHAZR_H

void gethazr(void);
#endif /* GETHAZR_H */
