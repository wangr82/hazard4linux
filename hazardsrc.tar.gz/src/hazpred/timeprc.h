#ifndef TIMEPRC_H
#define TIMEPRC_H

void timeprc(void);
#endif /* TIMEPRC_H */
