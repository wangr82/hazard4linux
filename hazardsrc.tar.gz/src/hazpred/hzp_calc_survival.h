#ifndef HZP_CALC_SURVIVAL_H
#define HZP_CALC_SURVIVAL_H

void hzp_calc_survival(void);
#endif /* HZP_CALC_SURVIVAL_H */
