#ifndef HAZVERR_H
#define HAZVERR_H 
void hazverr(int varnum);
#endif /* HAZVERR_H */
