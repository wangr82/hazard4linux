#ifndef GETFLAG_H
#define GETFLAG_H

int getflag(char *,int);
#endif /* GETFLAG_H */
