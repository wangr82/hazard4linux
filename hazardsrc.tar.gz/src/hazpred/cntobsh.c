#include <string.h>
#include "hazpred.h"
#include "stmtfld.h"
void cntobsh(void){
  totalobs = stmtfld(13);
}
