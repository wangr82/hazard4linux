#ifndef OBSLOOP_H
#define OBSLOOP_H

void obsloop(void);
#endif /* OBSLOOP_H */
