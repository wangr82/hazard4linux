#include <string.h>
#include "hzdinc.h"

void xlmode(int setting){
  curr_xlmode = setting;
}
