#ifndef NOTSPEC_H
#define NOTSPEC_H
#include "structures.h" /* Defines logical */

logical notspec(int fldno);
#endif /* NOTSPEC_H */
