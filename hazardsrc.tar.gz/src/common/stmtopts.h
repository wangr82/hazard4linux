#ifndef STMTOPTS_H
#define STMTOPTS_H
#include "structures.h" /* Defines logical */

logical stmtopts(int optno);

#endif /* STMTOPTS_H */

