#ifndef HZF_LOG2_H
#define HZF_LOG2_H

void hzf_log2(char *strg1,char *strg2);

#endif /* HZF_LOG2_H */
