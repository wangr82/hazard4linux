#ifndef HZD_LN_G1_AND_SG1_M_H
#define HZD_LN_G1_AND_SG1_M_H
void hzd_ln_G1_and_SG1_m(double T,double *lnG1,double *lnSG1);
#endif /* HZD_LN_G1_AND_SG1_M_H */
