#ifndef HZFPAG_H
#define HZFPAG_H

void hzfpag(int count);

#endif /* HZFPAG_H */
