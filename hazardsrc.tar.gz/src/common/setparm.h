#ifndef SETPARM_H
#define SETPARM_H

void setparm(int which,double towhat);

#endif /* SETPARM_H */
