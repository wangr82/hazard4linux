#ifndef XPMODE_H
#define XPMODE_H

void xpmode(int setting);

#endif /* XPMODE_H */
