#include <string.h>
#include "hzdinc.h"

void xpmode(int setting){
  curr_xpmode = setting;
}
