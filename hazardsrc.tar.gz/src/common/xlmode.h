#ifndef XLMODE_H
#define XLMODE_H

void xlmode(int setting);

#endif /* XLMODE_H */
