#ifndef STMTFLDNAME_H
#define STMTFLDNAME_H

char *stmtfldname(int fldno);

#endif /* STMTFLDNAME_H */

