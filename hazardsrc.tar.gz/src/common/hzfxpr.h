#ifndef HZFXPR_H
#define HZFXPR_H

void hzfxpr(char byte,int times,int column);

#endif /* HZFXPR_H */
