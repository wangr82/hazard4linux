#ifndef XVNAME_H
#define XVNAME_H

#include "hzdinc.h"

struct namestr *xvname(char *var);

#endif /* XVNAME_H */
