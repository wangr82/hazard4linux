#ifndef XOGET_H
#define XOGET_H
void xoget(void);
#endif /* XOGET_H */
