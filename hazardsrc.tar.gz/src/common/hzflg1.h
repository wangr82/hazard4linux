#ifndef HZFLG1_H
#define HZFLG1_H

void hzflg1(char *strg,int leng);

#endif /* HZFLG1_H */
