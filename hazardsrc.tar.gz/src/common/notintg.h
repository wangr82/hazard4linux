#ifndef NOTINTG_H
#define NOTINTG_H

#include "structures.h" /* defines logical */

logical notintg(double value);

#endif /* NOTINTG_H */
