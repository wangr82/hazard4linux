#ifndef XVPUTE_H
#define XVPUTE_H

void xvpute(void);

#endif /* XVPUTE_H */
