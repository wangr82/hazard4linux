#ifndef HZFXPF_H
#define HZFXPF_H

void hzfxpf(double value,int places,int precsn,int column);

#endif /* HZFXPF_H */
