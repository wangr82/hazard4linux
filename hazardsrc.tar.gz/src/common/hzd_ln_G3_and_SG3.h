#include "structures.h"

#ifndef HZD_LN_G3_AND_SG3_H
#define HZD_LN_G3_AND_SG3_H

void hzd_ln_G3_and_SG3(void);
#endif /* HZD_LN_G3_AND_SG3_H */
