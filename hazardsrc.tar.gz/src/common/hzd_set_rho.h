#ifndef HZD_SET_RHO_H
#define HZD_SET_RHO_H

void hzd_set_rho(struct early *Early);
#endif /* HZD_SET_RHO_H */
